var agentSystems = [];

document.addEventListener('DOMContentLoaded', async () => {
  // --- UI Elements ---
  const tabGenerator = document.getElementById('tab-generator');
  const tabSettings = document.getElementById('tab-settings');
  const tabAccount = document.getElementById('tab-account');
  const tabFeedback = document.getElementById('tab-feedback');

  const sectGenerator = document.getElementById('sect-generator');
  const sectSettings = document.getElementById('sect-settings');
  const sectAccount = document.getElementById('sect-account');
  const sectFeedback = document.getElementById('sect-feedback');

  const activeUrlSpan = document.getElementById('active-url');
  const scopeGlobal = document.getElementById('scope-global');
  const scopeWorkspace = document.getElementById('scope-workspace');
  const scopeHelp = document.getElementById('scope-help');

  const formatSelectorGroup = document.getElementById('format-selector-group');
  const formatRule = document.getElementById('format-rule');
  const formatSkill = document.getElementById('format-skill');
  
  const btnGenerate = document.getElementById('btn-generate');
  const btnText = btnGenerate ? btnGenerate.querySelector('.btn-text') : null;
  const btnLoader = btnGenerate ? btnGenerate.querySelector('.btn-loader') : null;

  const statusContainer = document.getElementById('status-container');
  const statusMsg = statusContainer ? statusContainer.querySelector('.status-message') : null;
  const statusIcon = statusContainer ? statusContainer.querySelector('.status-icon') : null;

  const apiKeyInput = document.getElementById('api-key-input');
  const clientIdInput = document.getElementById('client-id-input');
  const btnToggleKey = document.getElementById('btn-toggle-key');
  const workspaceInput = document.getElementById('workspace-input');
  const btnSaveSettings = document.getElementById('btn-save-settings');

  const connLocal = document.getElementById('conn-local');
  const connCloud = document.getElementById('conn-cloud');
  const cloudUrlInput = document.getElementById('cloud-url-input');
  const groupCloudUrl = document.getElementById('group-cloud-url');
  const groupWorkspacePath = document.getElementById('group-workspace-path');

  // BYOK Collapsible
  const byokToggle = document.getElementById('byok-toggle');
  const byokContent = document.getElementById('byok-content');

  // Agent Systems
  const sysAntigravity = document.getElementById('system-antigravity');
  const sysClaude = document.getElementById('system-claude');
  const sysCursor = document.getElementById('system-cursor');
  const sysWindsurf = document.getElementById('system-windsurf');
  const sysCopilot = document.getElementById('system-copilot');

  // Agent Systems Group
  agentSystems = [sysAntigravity, sysClaude, sysCursor, sysWindsurf, sysCopilot];


  // Upgrade Banner
  const upgradeBanner = document.getElementById('upgrade-banner');
  const btnUpgradeBanner = document.getElementById('btn-upgrade-banner');
  const btnByokBanner = document.getElementById('btn-byok-banner');

  // Account Tab Elements
  const loggedOutDiv = document.getElementById('account-logged-out');
  const loggedInDiv = document.getElementById('account-logged-in');
  const btnGoogleSignin = document.getElementById('btn-google-signin');
  const btnLogout = document.getElementById('btn-logout');
  const btnUpgradePro = document.getElementById('btn-upgrade-pro');
  
  const accountAvatar = document.getElementById('account-avatar');
  const accountEmail = document.getElementById('account-email');
  const tierBadge = document.getElementById('tier-badge');

  // Usage Progress
  const usageDailyText = document.getElementById('usage-daily-text');
  const usageDailyBar = document.getElementById('usage-daily-bar');
  const usageMonthlyText = document.getElementById('usage-monthly-text');
  const usageMonthlyBar = document.getElementById('usage-monthly-bar');

  // App State
  let activeTabUrl = '';
  let activeTabTitle = '';
  let currentScope = 'global'; // 'global' or 'workspace'
  let currentSystem = 'antigravity'; // 'antigravity', 'claude', 'cursor', 'windsurf', 'copilot'
  let currentConnMode = 'cloud'; // 'local' or 'cloud'
  let currentFormat = 'rule'; // 'rule' or 'skill'

  // --- Initialize App ---
  // (Initialization code moved to non-blocking init() function at the end)


  // --- Tab Navigation ---
  function switchTab(activeTab, activeSect) {
    [tabGenerator, tabSettings, tabAccount, tabFeedback].forEach(t => {
      if (t) t.classList.remove('active');
    });
    [sectGenerator, sectSettings, sectAccount, sectFeedback].forEach(s => {
      if (s) s.classList.remove('active');
    });
    if (activeTab) activeTab.classList.add('active');
    if (activeSect) activeSect.classList.add('active');
    hideStatus();
    hideFeedbackStatus();
  }

  if (tabGenerator) tabGenerator.addEventListener('click', () => switchTab(tabGenerator, sectGenerator));
  if (tabSettings) tabSettings.addEventListener('click', () => switchTab(tabSettings, sectSettings));
  if (tabAccount) tabAccount.addEventListener('click', () => switchTab(tabAccount, sectAccount));
  if (tabFeedback) tabFeedback.addEventListener('click', () => switchTab(tabFeedback, sectFeedback));

  // --- Feedback Functionality ---
  const btnSubmitFeedback = document.getElementById('btn-submit-feedback');
  const feedbackMessage = document.getElementById('feedback-message');
  const feedbackEmail = document.getElementById('feedback-email');
  const feedbackStatusContainer = document.getElementById('feedback-status-container');
  const feedbackStatusMsg = feedbackStatusContainer ? feedbackStatusContainer.querySelector('.status-message') : null;
  const feedbackStatusIcon = feedbackStatusContainer ? feedbackStatusContainer.querySelector('.status-icon') : null;
  const fbBug = document.getElementById('fb-bug');
  const fbSuggestion = document.getElementById('fb-suggestion');

  let activeFeedbackCategory = 'bug';
  if (fbBug && fbSuggestion) {
    fbBug.addEventListener('click', () => {
      fbBug.classList.add('active');
      fbSuggestion.classList.remove('active');
      activeFeedbackCategory = 'bug';
    });
    fbSuggestion.addEventListener('click', () => {
      fbSuggestion.classList.add('active');
      fbBug.classList.remove('active');
      activeFeedbackCategory = 'suggestion';
    });
  }

  if (btnSubmitFeedback) {
    btnSubmitFeedback.addEventListener('click', async () => {
      const message = feedbackMessage.value.trim();
      const email = feedbackEmail.value.trim();
      if (!message) {
        showFeedbackStatus('Please enter feedback details.', 'error');
        return;
      }
      
      setFeedbackSubmitting(true);
      hideFeedbackStatus();

      try {
        let activeUrl = 'Unknown';
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab && tab.url) activeUrl = tab.url;
        } catch (e) {
          console.error("Failed to query active tab for feedback context:", e);
        }

        let finalEmail = email;
        if (!finalEmail) {
          try {
            const authState = await chrome.storage.local.get(['session_email']);
            if (authState && authState.session_email) {
              finalEmail = authState.session_email;
            }
          } catch (e) {}
        }

        // Feedback always goes directly to the live production server so we collect real reports.
        const apiBase = 'https://tweetskill.vercel.app';
        
        const payload = {
          type: activeFeedbackCategory,
          message: message,
          email: finalEmail,
          context: {
            source: 'chrome-extension',
            tabUrl: activeUrl,
            userAgent: navigator.userAgent
          }
        };

        const response = await fetch(`${apiBase}/api/feedback`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        const result = await response.json();
        if (response.ok && result.status === 'ok') {
          showFeedbackStatus('Feedback submitted successfully! Thank you.', 'success');
          feedbackMessage.value = '';
        } else {
          showFeedbackStatus(result.message || 'Failed to submit feedback.', 'error');
        }
      } catch (err) {
        showFeedbackStatus(`Submission failed: ${err.message}`, 'error');
      } finally {
        setFeedbackSubmitting(false);
      }
    });
  }

  function setFeedbackSubmitting(submitting) {
    const btnText = btnSubmitFeedback.querySelector('.btn-text');
    const btnLoader = btnSubmitFeedback.querySelector('.btn-loader');
    if (submitting) {
      btnSubmitFeedback.disabled = true;
      btnText.textContent = 'Submitting...';
      btnLoader.classList.remove('hidden');
    } else {
      btnSubmitFeedback.disabled = false;
      btnText.textContent = 'Submit Feedback';
      btnLoader.classList.add('hidden');
    }
  }

  function showFeedbackStatus(msg, type) {
    if (!feedbackStatusContainer || !feedbackStatusMsg || !feedbackStatusIcon) return;
    feedbackStatusMsg.textContent = msg;
    feedbackStatusContainer.className = `status-box ${type}`;
    
    let svgIcon = '';
    if (type === 'success') {
      svgIcon = `
        <svg class="status-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
      `;
    } else {
      svgIcon = `
        <svg class="status-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
      `;
    }
    feedbackStatusIcon.innerHTML = svgIcon;
    feedbackStatusContainer.classList.remove('hidden');
  }

  function hideFeedbackStatus() {
    if (feedbackStatusContainer) feedbackStatusContainer.classList.add('hidden');
  }

  // --- BYOK Collapsible ---
  if (byokToggle && byokContent) {
    byokToggle.addEventListener('click', () => {
      byokToggle.classList.toggle('open');
      byokContent.classList.toggle('open');
    });
  }

  // --- Toggle Password Visibility ---
  if (btnToggleKey && apiKeyInput) {
    btnToggleKey.addEventListener('click', () => {
      if (apiKeyInput.type === 'password') {
        apiKeyInput.type = 'text';
        btnToggleKey.innerHTML = `
          <svg class="eye-icon closed-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
            <line x1="1" y1="1" x2="23" y2="23"></line>
          </svg>
        `;
      } else {
        apiKeyInput.type = 'password';
        btnToggleKey.innerHTML = `
          <svg class="eye-icon open-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
        `;
      }
    });
  }

  // --- Save Settings ---
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener('click', async () => {
      const key = apiKeyInput.value.trim();
      const wsPath = workspaceInput.value.trim();
      const cUrl = cloudUrlInput.value.trim();
      const gClientId = clientIdInput ? clientIdInput.value.trim() : '';
      
      await chrome.storage.local.set({ 
        apiKey: key, 
        workspacePath: wsPath,
        connectionMode: currentConnMode,
        cloudUrl: cUrl,
        googleClientId: gClientId
      });
      
      showStatus('success', 'Settings saved successfully!', '✅');
      await refreshUI();
      
      setTimeout(() => {
        if (tabGenerator) tabGenerator.click();
      }, 1000);
    });
  }

  // --- Scope Toggle Buttons ---
  if (scopeGlobal) {
    scopeGlobal.addEventListener('click', () => {
      currentScope = 'global';
      chrome.storage.local.set({ scope: currentScope });
      updateScopeUI();
    });
  }
 
  if (scopeWorkspace) {
    scopeWorkspace.addEventListener('click', () => {
      currentScope = 'workspace';
      chrome.storage.local.set({ scope: currentScope });
      updateScopeUI();
    });
  }

  // --- Connection Mode Toggles ---
  if (connLocal) {
    connLocal.addEventListener('click', () => {
      currentConnMode = 'local';
      chrome.storage.local.set({ connectionMode: currentConnMode });
      updateConnModeUI();
    });
  }

  if (connCloud) {
    connCloud.addEventListener('click', () => {
      currentConnMode = 'cloud';
      chrome.storage.local.set({ connectionMode: currentConnMode });
      updateConnModeUI();
    });
  }

  // --- Agent Systems Click Routing ---
  agentSystems.forEach(btn => {
    if (btn) {
      btn.addEventListener('click', async () => {
        const selected = btn.getAttribute('data-system');
        const tier = await Auth.getUserTier();
        
        // Gate Cursor, Windsurf, Copilot to Pro
        if (['cursor', 'windsurf', 'copilot'].includes(selected) && tier !== 'pro') {
          showStatus('warning', 'Cursor, Windsurf, and Copilot formats are exclusive to Pro tier users.', '⭐');
          if (upgradeBanner) upgradeBanner.classList.remove('hidden');
          return;
        }

        currentSystem = selected;
        chrome.storage.local.set({ system: currentSystem });
        updateSystemUI();
        updateScopeUI();
      });
    }
  });

  // --- Output Format Click Routing ---
  if (formatRule) {
    formatRule.addEventListener('click', () => {
      currentFormat = 'rule';
      chrome.storage.local.set({ agentFormat: currentFormat });
      updateFormatUI();
      updateSystemUI();
      updateScopeUI();
    });
  }
  if (formatSkill) {
    formatSkill.addEventListener('click', () => {
      currentFormat = 'skill';
      chrome.storage.local.set({ agentFormat: currentFormat });
      updateFormatUI();
      updateSystemUI();
      updateScopeUI();
    });
  }

  function updateFormatUI() {
    if (formatRule && formatSkill) {
      if (currentFormat === 'rule') {
        formatRule.classList.add('active');
        formatSkill.classList.remove('active');
      } else {
        formatSkill.classList.add('active');
        formatRule.classList.remove('active');
      }
    }
  }

  // --- Upgrade Action Routing ---
  const handleUpgrade = async () => {
    try {
      const userInfo = await Auth.getUserInfo();
      if (!userInfo || !userInfo.id) {
        showStatus('warning', 'Please sign in with Google first so we can link your Pro subscription to your account!', '🔑');
        // Switch to account tab
        if (typeof switchTab === 'function') {
          if (tabAccount && sectAccount) {
            switchTab(tabAccount, sectAccount);
          }
        }
        return;
      }

      // Default Stripe checkout link / payment link
      const { stripeCheckoutUrl } = await chrome.storage.local.get('stripeCheckoutUrl');
      const baseCheckoutUrl = stripeCheckoutUrl || 'https://buy.stripe.com/3cIaEXcXX4Ka31k0534sE01'; // Real live $9.99 Credits Pack link

      // Construct Stripe payment link URL with prefilled_email and client_reference_id
      const checkoutUrl = new URL(baseCheckoutUrl);
      checkoutUrl.searchParams.set('client_reference_id', userInfo.id);
      if (userInfo.email) {
        checkoutUrl.searchParams.set('prefilled_email', userInfo.email);
      }

      chrome.tabs.create({ url: checkoutUrl.toString() });
    } catch (err) {
      console.error('Error constructing checkout URL:', err);
      chrome.tabs.create({ url: 'https://tweet2skill.hero-apps.com/#pricing' });
    }
  };

  if (btnUpgradePro) btnUpgradePro.addEventListener('click', handleUpgrade);
  if (btnUpgradeBanner) btnUpgradeBanner.addEventListener('click', handleUpgrade);

  if (btnByokBanner) {
    btnByokBanner.addEventListener('click', () => {
      switchTab(tabSettings, sectSettings);
      if (byokToggle && byokContent && !byokToggle.classList.contains('open')) {
        byokToggle.classList.add('open');
        byokContent.classList.add('open');
      }
      if (apiKeyInput) {
        setTimeout(() => apiKeyInput.focus(), 150);
      }
    });
  }

  // --- Sign-in / Log-out Actions ---
  if (btnGoogleSignin) {
    btnGoogleSignin.addEventListener('click', async () => {
      try {
        hideStatus();
        btnGoogleSignin.disabled = true;
        const textSpan = btnGoogleSignin.querySelector('span');
        const origText = textSpan ? textSpan.textContent : 'Sign in with Google';
        if (textSpan) textSpan.textContent = 'Signing in...';

        await Auth.loginWithGoogle();
        
        if (textSpan) textSpan.textContent = origText;
        btnGoogleSignin.disabled = false;
        
        showStatus('success', 'Logged in successfully with Google!', '🚀');
        await refreshUI();
      } catch (err) {
        btnGoogleSignin.disabled = false;
        const textSpan = btnGoogleSignin.querySelector('span');
        if (textSpan) textSpan.textContent = 'Sign in with Google';
        showStatus('error', `Login failed: ${err.message}`, '❌');
      }
    });
  }

  if (btnLogout) {
    btnLogout.addEventListener('click', async () => {
      hideStatus();
      await Auth.logout();
      showStatus('success', 'Logged out successfully.', '✅');
      await refreshUI();
    });
  }

  // --- Detect Active Tab URL ---
  // (Active tab detection moved to non-blocking init() function at the end)

  // --- Generate Skill Trigger ---
  if (btnGenerate) {
    btnGenerate.addEventListener('click', async () => {
      hideStatus();
      
      const { apiKey, workspacePath, connectionMode, cloudUrl } = await chrome.storage.local.get([
        'apiKey', 'workspacePath', 'connectionMode', 'cloudUrl'
      ]);
      
      const wsPath = workspacePath || '';
      const connMode = connectionMode || 'cloud';
      const tier = await Auth.getUserTier();
      const usage = await Auth.fetchUsage();

      // Check daily and weekly free limits
      if (tier === 'free') {
        const dailyLimitReached = usage && usage.daily && usage.daily.used >= usage.daily.limit;
        const weeklyLimitReached = usage && usage.weekly && usage.weekly.used >= usage.weekly.limit;
        if (dailyLimitReached || weeklyLimitReached) {
          const reason = dailyLimitReached ? 'Daily free limit reached.' : 'Weekly free limit reached.';
          showStatus('error', `${reason} Bring your own key in Settings or buy Pro credits.`, '⚠️');
          if (upgradeBanner) upgradeBanner.classList.remove('hidden');
          return;
        }
      }

      // Check Pro credits limit
      if (tier === 'pro') {
        const isLegacyActive = (usage && usage.subscription === 'active');
        if (!isLegacyActive) {
          const creditsRemaining = (usage && usage.credits && usage.credits.remaining !== undefined) ? usage.credits.remaining : 0;
          if (creditsRemaining <= 0) {
            showStatus('error', 'No credits remaining. Please buy more credits in Settings or add your own API key.', '⚠️');
            if (upgradeBanner) upgradeBanner.classList.remove('hidden');
            return;
          }
        }
      }

      // Check Pro format locks
      if (['cursor', 'windsurf', 'copilot'].includes(currentSystem) && tier !== 'pro') {
        showStatus('error', 'Selected format requires a Pro subscription.', '⚠️');
        if (upgradeBanner) upgradeBanner.classList.remove('hidden');
        return;
      }

      // Check Workspace Scope Local requirements
      if (currentScope === 'workspace' && connMode === 'local' && !wsPath) {
        showStatus('error', 'Please configure your Local Workspace Path in Settings to use Workspace scope.', '⚠️');
        switchTab(tabSettings, sectSettings);
        return;
      }

      setGenerating(true);

      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) {
          throw new Error('No active tab found.');
        }

        // Inject content extraction script with Pro Deep Capture parameter
        const deepCaptureToggle = document.getElementById('toggle-deep-capture');
        const deepCapture = deepCaptureToggle ? deepCaptureToggle.checked : false;

        const injectionResults = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: extractPageContent,
          args: [deepCapture]
        });

        if (!injectionResults || !injectionResults[0] || !injectionResults[0].result) {
          throw new Error('Could not extract content from the page.');
        }

        const { type, title, content } = injectionResults[0].result;

        if (!content || content.trim().length === 0) {
          throw new Error('Selected page content is empty.');
        }

        if (connMode === 'local') {
          // Native Bridge payload
          const hostName = 'com.antigravity.linker';
          const { authJwt } = await chrome.storage.local.get('authJwt');
          
          const payload = {
            url: tab.url,
            title: title || tab.title || 'Untitled Page',
            contentType: type,
            content: content,
            scope: currentScope,
            workspacePath: wsPath,
            agentSystem: currentSystem,
            deviceId: await Auth.getDeviceId(),
            authToken: authJwt || ''
          };

          if (tier === 'byok' && apiKey) {
            payload.apiKey = apiKey;
          }

          chrome.runtime.sendNativeMessage(hostName, payload, (response) => {
            setGenerating(false);
            if (chrome.runtime.lastError) {
              console.error(chrome.runtime.lastError);
              showStatus('error', `
                <strong>Local Native Bridge Error</strong>: ${chrome.runtime.lastError.message}.<br><br>
                <strong>How to fix this:</strong><br>
                1. <strong>Quickest:</strong> Go to <strong>Settings</strong> and switch connection mode to <strong>Cloud Vercel</strong> (uses our high-speed cloud endpoint with zero setup required!).<br>
                2. <strong>Local Sync:</strong> Open your terminal in the extension folder and run:<br>
                <code style="background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 4px; font-family: monospace;">python3 install.py</code>
              `, '❌');
            } else if (response && response.status === 'done') {
              showStatus('success', response.message.replace(/\n/g, '<br>'), '🚀');
              setTimeout(refreshUI, 1000);
            } else {
              const errMsg = response ? response.message : 'Unknown error from native host.';
              showStatus('error', `Error: ${errMsg}`, '❌');
            }
          });
        } else {
          // Cloud Vercel payload
          let apiEndpoint = (cloudUrl && cloudUrl.trim().length > 0) ? cloudUrl.trim() : Auth.DEFAULT_API_BASE;

          if (!apiEndpoint.startsWith('http://') && !apiEndpoint.startsWith('https://')) {
            apiEndpoint = 'https://' + apiEndpoint;
          }
          if (!apiEndpoint.endsWith('/api/generate') && !apiEndpoint.endsWith('/api/generate/')) {
            apiEndpoint = apiEndpoint.replace(/\/$/, '') + '/api/generate';
          }

          const payload = {
            url: tab.url,
            title: title || tab.title || 'Untitled Page',
            contentType: type,
            content: content,
            agentSystem: currentSystem
          };

          if (tier === 'byok' && apiKey) {
            payload.apiKey = apiKey;
          }

          const headers = await Auth.getAuthHeaders();

          const response = await fetch(apiEndpoint, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(payload)
          });

          if (!response.ok) {
            const errBody = await response.json().catch(() => ({}));
            throw new Error(errBody.message || `API returned HTTP ${response.status}`);
          }

          const resData = await response.json();
          setGenerating(false);

          if (resData.status === 'done' && resData.markdown) {
            // Determine friendly path display
            let targetPath = '';
            if (currentSystem === 'antigravity') {
              targetPath = currentScope === 'global' 
                ? `~/.gemini/config/skills/${resData.slug}/SKILL.md` 
                : `.agents/skills/${resData.slug}/SKILL.md`;
            } else if (currentSystem === 'claude') {
              targetPath = currentScope === 'global' 
                ? `~/.claude/rules/${resData.slug}.md` 
                : `.claude/rules/${resData.slug}.md`;
            } else if (currentSystem === 'cursor') {
              targetPath = currentScope === 'global' 
                ? `~/.cursor/rules/${resData.slug}.md` 
                : `.cursor/rules/${resData.slug}.md`;
            } else if (currentSystem === 'windsurf') {
              targetPath = currentScope === 'global' 
                ? `~/.windsurfrules` 
                : `.windsurfrules`;
            } else if (currentSystem === 'copilot') {
              targetPath = currentScope === 'global' 
                ? `~/.github/copilot-instructions.md` 
                : `.github/copilot-instructions.md`;
            }

            // Determine download filename
            let filename = '';
            if (currentSystem === 'antigravity') {
              filename = `${resData.slug}/SKILL.md`;
            } else if (currentSystem === 'claude' || currentSystem === 'cursor') {
              filename = `${resData.slug}.md`;
            } else if (currentSystem === 'windsurf') {
              filename = `.windsurfrules`;
            } else if (currentSystem === 'copilot') {
              filename = `copilot-instructions.md`;
            }

            const blobUrl = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(resData.markdown);

            chrome.downloads.download({
              url: blobUrl,
              filename: filename,
              saveAs: true
            }, (downloadId) => {
              if (chrome.runtime.lastError) {
                showStatus('error', `Download failed: ${chrome.runtime.lastError.message}`, '❌');
              } else {
                const labelText = currentSystem === 'antigravity' ? 'SKILL PATH' : 'RULE PATH';
                const htmlContent = `
                  <div style="font-weight: 700; margin-bottom: 4px;">Generation Successful!</div>
                  <div style="font-size: 11px; opacity: 0.95; margin-bottom: 6px;">Save the downloaded file exactly to this path:</div>
                  <div style="background: rgba(0,0,0,0.4); padding: 6px; border-radius: 4px; font-family: monospace; font-size: 11px; word-break: break-all; border: 1px solid rgba(255,255,255,0.15); margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center; gap: 8px;">
                    <span style="color: #a8ff35; font-weight: 500;">${targetPath}</span>
                    <button id="btn-copy-path" style="background: #ffffff; border: none; color: #000000; padding: 2px 8px; border-radius: 3px; cursor: pointer; font-size: 10px; font-family: var(--font-family); font-weight: 700; flex-shrink: 0; transition: all 0.2s;">COPY PATH</button>
                  </div>
                  <div style="display: flex; gap: 6px; margin-top: 6px;">
                    <button id="btn-copy-markdown" style="flex: 1; background: #a8ff35; border: none; color: #000000; padding: 6px; border-radius: 4px; cursor: pointer; font-size: 11px; font-family: var(--font-family); font-weight: 700; transition: all 0.2s; display: flex; align-items: center; justify-content: center; gap: 4px;">
                      <span>📋 COPY SKILL MARKDOWN</span>
                    </button>
                  </div>
                  <div style="font-size: 10px; opacity: 0.8; margin-top: 6px; line-height: 1.3; text-align: left;">
                    💡 <strong>macOS Tip:</strong> In the Save window, press <code style="background: rgba(255,255,255,0.15); padding: 1px 4px; border-radius: 3px; font-family: monospace;">Cmd+Shift+.</code> to show hidden folders like <code style="background: rgba(255,255,255,0.15); padding: 1px 4px; border-radius: 3px; font-family: monospace;">.agents</code>!
                  </div>
                `;
                showStatus('success', htmlContent, '🚀');
                
                const copyBtn = document.getElementById('btn-copy-path');
                if (copyBtn) {
                  copyBtn.addEventListener('click', () => {
                    navigator.clipboard.writeText(targetPath);
                    copyBtn.textContent = 'COPIED!';
                    copyBtn.style.background = '#a8ff35';
                    setTimeout(() => { 
                      copyBtn.textContent = 'COPY PATH'; 
                      copyBtn.style.background = '#ffffff';
                    }, 1500);
                  });
                }

                const copyMarkdownBtn = document.getElementById('btn-copy-markdown');
                if (copyMarkdownBtn) {
                  copyMarkdownBtn.addEventListener('click', () => {
                    navigator.clipboard.writeText(resData.markdown);
                    const btnSpan = copyMarkdownBtn.querySelector('span');
                    if (btnSpan) btnSpan.textContent = '✓ MARKDOWN COPIED!';
                    copyMarkdownBtn.style.background = '#7cd315';
                    setTimeout(() => {
                      if (btnSpan) btnSpan.textContent = '📋 COPY SKILL MARKDOWN';
                      copyMarkdownBtn.style.background = '#a8ff35';
                    }, 1500);
                  });
                }
                setTimeout(refreshUI, 1000);
              }
            });
          } else {
            throw new Error(resData.message || 'Malformed response from Vercel API.');
          }
        }
      } catch (err) {
        setGenerating(false);
        showStatus('error', `Generation failed: ${err.message}`, '❌');
      }
    });
  }

  // --- Helper Functions ---

  async function checkAuthMe() {
    const { authJwt } = await chrome.storage.local.get('authJwt');
    if (!authJwt) return;

    try {
      const apiBase = await Auth.getApiBase();
      const headers = await Auth.getAuthHeaders();
      const res = await fetch(`${apiBase}/api/auth_me`, {
        method: 'GET',
        headers
      });

      if (res.ok) {
        const data = await res.json();
        if (data.status === 'ok' && data.user) {
          await chrome.storage.local.set({
            userInfo: {
              email: data.user.email,
              name: data.user.name || '',
              tier: data.user.tier || 'free',
              avatar: data.user.picture || ''
            }
          });
        }
      } else if (res.status === 401) {
        // Token has expired or is invalid
        await Auth.logout();
      }
    } catch (e) {
      console.warn('Failed to verify token on startup:', e);
    }
  }

  async function refreshUI() {
    const tier = await Auth.getUserTier();
    const userInfo = await Auth.getUserInfo();
    const usage = await Auth.fetchUsage();

    // 1. Update Header Badge
    const usageBadge = document.getElementById('usage-badge');
    const badgeText = usageBadge ? usageBadge.querySelector('.usage-badge-text') : null;
    
    if (usageBadge && badgeText) {
      if (tier === 'pro') {
        usageBadge.className = 'usage-badge is-pro';
        badgeText.textContent = 'PRO';
      } else if (tier === 'byok') {
        usageBadge.className = 'usage-badge is-byok';
        badgeText.textContent = 'BYOK';
      } else {
        const dailyUsed = (usage && usage.daily && usage.daily.used !== null && usage.daily.used !== undefined) ? usage.daily.used : 0;
        const dailyLimit = (usage && usage.daily && usage.daily.limit !== null && usage.daily.limit !== undefined) ? usage.daily.limit : 3;
        usageBadge.className = 'usage-badge' + (dailyUsed >= dailyLimit ? ' near-limit' : '');
        badgeText.textContent = `${dailyUsed}/${dailyLimit}`;
      }
    }

    // 2. Lock / Unlock system toggle options based on tier
    agentSystems.forEach(btn => {
      if (btn) {
        const system = btn.getAttribute('data-system');
        if (['cursor', 'windsurf', 'copilot'].includes(system)) {
          if (tier === 'pro') {
            btn.classList.remove('pro-locked');
          } else {
            btn.classList.add('pro-locked');
            // If the selected option got locked, fallback selection to antigravity
            if (btn.classList.contains('active')) {
              btn.classList.remove('active');
              currentSystem = 'antigravity';
              if (sysAntigravity) sysAntigravity.classList.add('active');
              chrome.storage.local.set({ system: currentSystem });
              updateSystemUI();
              updateScopeUI();
            }
          }
        }
      }
    });

    // 3. Toggle and update upgrade banner
    if (upgradeBanner) {
      const bannerStrong = upgradeBanner.querySelector('.upgrade-banner-text strong');
      const bannerSpan = upgradeBanner.querySelector('.upgrade-banner-text span');
      const bannerBtn = document.getElementById('btn-upgrade-banner');

      if (tier === 'free') {
        const dailyLimitReached = usage && usage.daily && usage.daily.used >= usage.daily.limit;
        const weeklyLimitReached = usage && usage.weekly && usage.weekly.used >= usage.weekly.limit;
        if (dailyLimitReached || weeklyLimitReached) {
          upgradeBanner.classList.remove('hidden');
          if (bannerStrong) {
            bannerStrong.textContent = dailyLimitReached ? 'Daily limit reached!' : 'Weekly limit reached!';
          }
          if (bannerSpan) {
            bannerSpan.textContent = 'Upgrade to Pro (2,500 credits) or use your own key';
          }
          if (bannerBtn) {
            bannerBtn.innerHTML = 'Get Credits — $9.99';
          }
        } else {
          upgradeBanner.classList.add('hidden');
        }
      } else if (tier === 'pro') {
        const isLegacyActive = (usage && usage.subscription === 'active');
        if (!isLegacyActive) {
          const creditsRemaining = (usage && usage.credits && usage.credits.remaining !== undefined) ? usage.credits.remaining : 0;
          if (creditsRemaining <= 0) {
            upgradeBanner.classList.remove('hidden');
            if (bannerStrong) bannerStrong.textContent = 'Out of credits!';
            if (bannerSpan) bannerSpan.textContent = 'Buy 2,500 more credits or use your own API key';
            if (bannerBtn) bannerBtn.innerHTML = 'Buy Credits — $9.99';
          } else {
            upgradeBanner.classList.add('hidden');
          }
        } else {
          upgradeBanner.classList.add('hidden');
        }
      } else {
        upgradeBanner.classList.add('hidden');
      }
    }

    // 4. Update Account Section Logged In/Out state
    if (userInfo && userInfo.email) {
      if (loggedOutDiv) loggedOutDiv.classList.add('hidden');
      if (loggedInDiv) loggedInDiv.classList.remove('hidden');

      if (accountEmail) accountEmail.textContent = userInfo.email;

      if (accountAvatar) {
        if (userInfo.avatar) {
          accountAvatar.innerHTML = `<img src="${userInfo.avatar}" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">`;
        } else {
          const initial = userInfo.email.charAt(0).toUpperCase();
          accountAvatar.innerHTML = `<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: var(--text-primary); font-size: 14px;">${initial}</div>`;
        }
      }

      if (tierBadge) {
        if (tier === 'pro') {
          tierBadge.className = 'tier-badge tier-pro';
          tierBadge.textContent = 'PRO';
        } else {
          tierBadge.className = 'tier-badge tier-free';
          tierBadge.textContent = 'FREE';
        }
      }

      if (btnUpgradePro) {
        const upgradeProSpan = btnUpgradePro.querySelector('span');
        if (tier === 'pro') {
          const isLegacyActive = (usage && usage.subscription === 'active');
          if (isLegacyActive) {
            btnUpgradePro.classList.add('hidden');
          } else {
            btnUpgradePro.classList.remove('hidden');
            if (upgradeProSpan) {
              upgradeProSpan.textContent = 'Buy 2,500 Credits — $9.99';
            }
          }
        } else {
          btnUpgradePro.classList.remove('hidden');
          if (upgradeProSpan) {
            upgradeProSpan.textContent = 'Upgrade to Pro — $9.99';
          }
        }
      }
    } else {
      if (loggedOutDiv) loggedOutDiv.classList.remove('hidden');
      if (loggedInDiv) loggedInDiv.classList.add('hidden');
    }

    // 5. Update Account Stats & Bars
    if (usageDailyText && usageDailyBar && usageMonthlyText && usageMonthlyBar) {
      const usageDailyLabel = document.getElementById('usage-daily-label');
      const usageMonthlyLabel = document.getElementById('usage-monthly-label');
      const usageMonthlyRow = document.getElementById('usage-monthly-row');

      if (tier === 'pro') {
        const isLegacyActive = (usage && usage.subscription === 'active');
        
        if (isLegacyActive) {
          if (usageDailyLabel) usageDailyLabel.textContent = 'Monthly Usage';
          const monthlyUsed = (usage && usage.monthly) ? usage.monthly.used : 0;
          const monthlyLimit = (usage && usage.monthly) ? usage.monthly.limit : 1250;
          usageDailyText.textContent = `${monthlyUsed} / ${monthlyLimit}`;
          const pct = Math.min(100, (monthlyUsed / monthlyLimit) * 100);
          usageDailyBar.style.width = `${pct}%`;
          
          if (usageMonthlyRow) usageMonthlyRow.classList.add('hidden');
        } else {
          if (usageDailyLabel) usageDailyLabel.textContent = 'Credits Remaining';
          const creditsRemaining = (usage && usage.credits && usage.credits.remaining !== undefined) ? usage.credits.remaining : 0;
          usageDailyText.textContent = `${creditsRemaining.toLocaleString()} / 2,500`;
          const creditPct = Math.min(100, (creditsRemaining / 2500) * 100);
          usageDailyBar.style.width = `${creditPct}%`;
          
          if (usageMonthlyRow) usageMonthlyRow.classList.add('hidden');
        }
      } else if (tier === 'byok') {
        if (usageDailyLabel) usageDailyLabel.textContent = 'Daily Usage';
        usageDailyText.textContent = 'Unlimited';
        usageDailyBar.style.width = '100%';
        
        if (usageMonthlyRow) usageMonthlyRow.classList.add('hidden');
      } else {
        if (usageDailyLabel) usageDailyLabel.textContent = 'Daily Usage';
        const dailyUsed = (usage && usage.daily && usage.daily.used !== null && usage.daily.used !== undefined) ? usage.daily.used : 0;
        const dailyLimit = (usage && usage.daily && usage.daily.limit !== null && usage.daily.limit !== undefined) ? usage.daily.limit : 3;
        usageDailyText.textContent = `${dailyUsed} / ${dailyLimit}`;
        const dailyPct = dailyLimit > 0 ? Math.min(100, (dailyUsed / dailyLimit) * 100) : 0;
        usageDailyBar.style.width = `${dailyPct}%`;

        if (usageMonthlyRow) usageMonthlyRow.classList.remove('hidden');
        if (usageMonthlyLabel) usageMonthlyLabel.textContent = 'Weekly Usage';
        
        const weeklyUsed = (usage && usage.weekly && usage.weekly.used !== null && usage.weekly.used !== undefined) ? usage.weekly.used : 0;
        const weeklyLimit = (usage && usage.weekly && usage.weekly.limit !== null && usage.weekly.limit !== undefined) ? usage.weekly.limit : 10;
        usageMonthlyText.textContent = `${weeklyUsed} / ${weeklyLimit}`;
        const weeklyPct = weeklyLimit > 0 ? Math.min(100, (weeklyUsed / weeklyLimit) * 100) : 0;
        usageMonthlyBar.style.width = `${weeklyPct}%`;
      }
    }

    // 6. Update Pro Options Visibility (Twitter Deep Capture)
    const proOptions = document.getElementById('pro-options');
    if (proOptions) {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const isTwitter = activeTab && (activeTab.url && (activeTab.url.includes('x.com') || activeTab.url.includes('twitter.com')));
      if (tier === 'pro' && isTwitter) {
        proOptions.classList.remove('hidden');
      } else {
        proOptions.classList.add('hidden');
      }
    }
  }

  function updateSystemUI() {
    agentSystems.forEach(btn => {
      if (btn) {
        if (btn.getAttribute('data-system') === currentSystem) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      }
    });

    if (formatSelectorGroup) {
      if (currentSystem === 'claude') {
        formatSelectorGroup.classList.remove('hidden');
      } else {
        formatSelectorGroup.classList.add('hidden');
      }
    }

    if (btnText) {
      if (currentSystem === 'antigravity' || (currentSystem === 'claude' && currentFormat === 'skill')) {
        btnText.textContent = 'Turn into Skill';
      } else {
        btnText.textContent = 'Turn into Rule';
      }
    }
  }
 
  function updateScopeUI() {
    if (!scopeHelp) return;

    if (currentScope === 'global') {
      if (scopeGlobal) scopeGlobal.classList.add('active');
      if (scopeWorkspace) scopeWorkspace.classList.remove('active');

      if (currentSystem === 'antigravity') {
        scopeHelp.textContent = 'Saves to ~/.gemini/config/skills/';
      } else if (currentSystem === 'claude') {
        if (currentFormat === 'skill') {
          scopeHelp.textContent = 'Saves to ~/.claude/skills/';
        } else {
          scopeHelp.textContent = 'Saves to ~/.claude/rules/';
        }
      } else if (currentSystem === 'cursor') {
        scopeHelp.textContent = 'Saves to ~/.cursor/rules/';
      } else if (currentSystem === 'windsurf') {
        scopeHelp.textContent = 'Appends to ~/.windsurfrules';
      } else if (currentSystem === 'copilot') {
        scopeHelp.textContent = 'Appends to ~/.github/copilot-instructions.md';
      }
    } else {
      if (scopeWorkspace) scopeWorkspace.classList.add('active');
      if (scopeGlobal) scopeGlobal.classList.remove('active');

      if (currentSystem === 'antigravity') {
        scopeHelp.textContent = 'Saves to project-folder/.agents/skills/';
      } else if (currentSystem === 'claude') {
        if (currentFormat === 'skill') {
          scopeHelp.textContent = 'Saves to project-folder/.claude/skills/';
        } else {
          scopeHelp.textContent = 'Saves to project-folder/.claude/rules/';
        }
      } else if (currentSystem === 'cursor') {
        scopeHelp.textContent = 'Saves to project-folder/.cursor/rules/';
      } else if (currentSystem === 'windsurf') {
        scopeHelp.textContent = 'Appends to project-folder/.windsurfrules';
      } else if (currentSystem === 'copilot') {
        scopeHelp.textContent = 'Appends to project-folder/.github/copilot-instructions.md';
      }
    }
  }

  function updateConnModeUI() {
    if (currentConnMode === 'local') {
      if (connLocal) connLocal.classList.add('active');
      if (connCloud) connCloud.classList.remove('active');
      if (groupWorkspacePath) groupWorkspacePath.style.display = 'block';
      if (groupCloudUrl) groupCloudUrl.style.display = 'none';
    } else {
      if (connCloud) connCloud.classList.add('active');
      if (connLocal) connLocal.classList.remove('active');
      if (groupWorkspacePath) groupWorkspacePath.style.display = 'none';
      if (groupCloudUrl) groupCloudUrl.style.display = 'block';
    }
  }

  function showStatus(type, message, iconText) {
    if (!statusContainer || !statusMsg || !statusIcon) return;

    statusContainer.className = `status-box ${type}`;
    statusMsg.innerHTML = message;
    
    let svgIcon = '';
    if (type === 'success') {
      svgIcon = `
        <svg class="status-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
      `;
    } else if (type === 'error') {
      svgIcon = `
        <svg class="status-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="15" y1="9" x2="9" y2="15"></line>
          <line x1="9" y1="9" x2="15" y2="15"></line>
        </svg>
      `;
    } else {
      svgIcon = `
        <svg class="status-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
      `;
    }
    statusIcon.innerHTML = svgIcon;
    statusContainer.classList.remove('hidden');
  }

  function hideStatus() {
    if (statusContainer) statusContainer.classList.add('hidden');
  }

  function setGenerating(isGenerating) {
    if (!btnGenerate || !btnText || !btnLoader) return;
    
    if (isGenerating) {
      btnGenerate.disabled = true;
      btnText.textContent = (currentSystem === 'antigravity' || (currentSystem === 'claude' && currentFormat === 'skill')) ? 'Generating Skill...' : 'Generating Rule...';
      btnLoader.classList.remove('hidden');
    } else {
      btnGenerate.disabled = false;
      btnText.textContent = (currentSystem === 'antigravity' || (currentSystem === 'claude' && currentFormat === 'skill')) ? 'Turn into Skill' : 'Turn into Rule';
      btnLoader.classList.add('hidden');
    }
  }

  // Content extraction function injected into the active tab
  // Content extraction function injected into the active tab
  async function extractPageContent(deepCapture) {
    const selection = window.getSelection().toString().trim();
    if (selection) {
      return { type: 'selection', title: document.title, content: selection };
    }

    const url = window.location.href;
    const isTwitter = url.includes('x.com') || url.includes('twitter.com');

    if (isTwitter) {
      // 1. Check for X Article / Longform Post first
      const articleEl = document.querySelector('[data-testid="articleBody"]') ||
                        document.querySelector('[data-testid="twitterArticle"]') ||
                        (url.includes('/article/') ? document.querySelector('article') : null);
      if (articleEl) {
        const articleTitle = document.querySelector('h1')?.innerText || document.title;
        const text = articleEl.innerText.trim();
        if (text && text.length > 200) {
          return {
            type: 'article',
            title: `X Article: ${articleTitle}`,
            content: text
          };
        }
      }

      const urlParts = url.split('/');
      const statusIndex = urlParts.indexOf('status');
      let authorHandle = '';
      if (statusIndex > 1) {
        authorHandle = urlParts[statusIndex - 1].toLowerCase();
      }

      // Low-signal filter helper for thread continuations and comment noise
      const isLowSignalReply = (text) => {
        if (!text) return true;
        const stripped = text.replace(/@\w+/g, '').replace(/[^\p{L}\p{N}\s]/gu, '').replace(/\s+/g, ' ').toLowerCase().trim();
        if (!stripped) return true;
        
        const lowSignalPhrases = [
          'thanks', 'thank you', 'thx', 'appreciate it', 'glad to help', 'glad you liked it',
          'youre welcome', 'anytime', 'bookmarked', 'bookmark', 'agree', 'agreed',
          'totally', '100', 'facts', 'true', 'dm', 'check dm', 'check dms', 'sent',
          'done', 'cool', 'awesome', 'nice', 'great', 'wow', 'lets go', 'following', 'qt'
        ];
        
        if (stripped.length < 35 && lowSignalPhrases.some(p => stripped === p || stripped.startsWith(p) || stripped.endsWith(p))) {
          return true;
        }
        return false;
      };

      // Accumulated tweets map across scroll steps to prevent losing top posts when Twitter unmounts DOM nodes
      const accumulatedTweets = new Map();

      const collectTweets = () => {
        const tweets = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
        
        tweets.forEach((tweet) => {
          const userDiv = tweet.querySelector('[data-testid="User-Name"]');
          const textDiv = tweet.querySelector('[data-testid="tweetText"]');
          const timeEl = tweet.querySelector('time');
          
          if (textDiv) {
            const text = textDiv.innerText.trim();
            if (!text) return;

            // Generate a stable key for the tweet
            let tweetKey = '';
            if (timeEl && timeEl.parentElement && timeEl.parentElement.getAttribute('href')) {
              tweetKey = timeEl.parentElement.getAttribute('href');
            } else {
              tweetKey = text.slice(0, 100).replace(/\s+/g, ' ');
            }

            if (userDiv) {
              const handleMatch = userDiv.innerText.match(/@(\w+)/);
              const handle = handleMatch ? handleMatch[1].toLowerCase() : '';
              
              // Only collect tweets by the original author
              if (!authorHandle || handle === authorHandle) {
                // If it's a continuation tweet (not the root tweet), reject low-signal pleasantries
                if (accumulatedTweets.size > 0 && isLowSignalReply(text)) {
                  return;
                }
                if (!accumulatedTweets.has(tweetKey)) {
                  accumulatedTweets.set(tweetKey, text);
                }
              }
            } else if (!authorHandle) {
              if (!accumulatedTweets.has(tweetKey)) {
                accumulatedTweets.set(tweetKey, text);
              }
            }
          }
        });
        return Array.from(accumulatedTweets.values());
      };

      if (deepCapture) {
        // PRO FEATURE: Auto-scroll to capture the complete thread without losing top posts
        let previousCount = 0;
        let scrollAttempts = 0;
        let consecutiveNoNewTweets = 0;
        const maxScrolls = 10;

        while (scrollAttempts < maxScrolls) {
          const currentList = collectTweets();
          
          if (currentList.length === previousCount) {
            consecutiveNoNewTweets++;
            // If after 2 scrolls no new author tweets are found, stop scrolling early
            if (consecutiveNoNewTweets >= 2) break;
          } else {
            consecutiveNoNewTweets = 0;
          }
          
          previousCount = currentList.length;
          window.scrollBy(0, 800);
          if (document.documentElement) document.documentElement.scrollTop += 800;
          if (document.body) document.body.scrollTop += 800;
          
          await new Promise(r => setTimeout(r, 650));
          scrollAttempts++;
        }
        
        // Scroll back to top smoothly
        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (document.documentElement) document.documentElement.scrollTo({ top: 0, behavior: 'smooth' });

        const allTweets = Array.from(accumulatedTweets.values());
        if (allTweets.length > 0) {
          const formattedThread = allTweets.map((t, idx) => {
            const label = idx === 0 ? `[Tweet 1 - Main Post / Core Topic]` : `[Tweet ${idx + 1}]`;
            return `${label}\n${t}`;
          }).join('\n\n---\n\n');

          return {
            type: 'tweet',
            title: `Deep Captured Thread by @${authorHandle || 'author'} (${allTweets.length} tweet${allTweets.length > 1 ? 's' : ''})`,
            content: formattedThread
          };
        }
      } else {
        // Standard Capture
        collectTweets();
        const allTweets = Array.from(accumulatedTweets.values());
        if (allTweets.length > 0) {
          const formattedThread = allTweets.map((t, idx) => {
            const label = idx === 0 ? `[Tweet 1 - Main Post / Core Topic]` : `[Tweet ${idx + 1}]`;
            return `${label}\n${t}`;
          }).join('\n\n---\n\n');

          return {
            type: 'tweet',
            title: `Tweet/Thread by @${authorHandle || 'author'}`,
            content: formattedThread
          };
        }
      }
    }

    // General fallback reader mode extraction
    const container = document.querySelector('article') || document.querySelector('main') || document.body;
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = container.innerHTML;
    
    const elementsToRemove = tempDiv.querySelectorAll('script, style, nav, footer, header, noscript, iframe');
    elementsToRemove.forEach(el => el.remove());
    
    let contentText = tempDiv.innerText.replace(/\s+/g, ' ').trim();
    
    if (contentText.length > 15000) {
      contentText = contentText.substring(0, 15000) + '\n\n... [Content Truncated due to Length]';
    }

    return {
      type: 'general',
      title: document.title,
      content: contentText
    };
  }

  // --- Async Initialization ---
  async function init() {
    try {
      // 1. Detect Active Tab URL
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url) {
        activeTabUrl = tab.url;
        activeTabTitle = tab.title || '';
        if (activeUrlSpan) {
          activeUrlSpan.textContent = activeTabUrl;
          activeUrlSpan.title = activeTabUrl;
        }
      } else {
        if (activeUrlSpan) activeUrlSpan.textContent = 'No active tab detected';
      }
    } catch (err) {
      console.error('Failed to get active tab:', err);
      if (activeUrlSpan) activeUrlSpan.textContent = 'Error detecting page';
    }

    try {
      // 2. Initial verification of Auth token
      await checkAuthMe();

      // 3. Load settings from storage
      const settings = await chrome.storage.local.get([
        'apiKey', 'scope', 'workspacePath', 'system', 'connectionMode', 'cloudUrl', 'googleClientId', 'agentFormat'
      ]);

      if (apiKeyInput && settings.apiKey) apiKeyInput.value = settings.apiKey;
      if (clientIdInput) clientIdInput.value = settings.googleClientId || '';
      if (workspaceInput) workspaceInput.value = settings.workspacePath || '';
      if (cloudUrlInput) cloudUrlInput.value = settings.cloudUrl || '';
      
      if (settings.scope) currentScope = settings.scope;
      if (settings.system) currentSystem = settings.system;
      if (settings.connectionMode) currentConnMode = settings.connectionMode;
      if (settings.agentFormat) currentFormat = settings.agentFormat;

      updateFormatUI();
      updateScopeUI();
      updateSystemUI();
      updateConnModeUI();
      
      // 4. Initial UI refresh (badge, bars, locks, banner)
      await refreshUI();

      // 5. Check background OAuth persistent state
      const authState = await chrome.storage.local.get(['lastAuthStatus', 'lastAuthError']);
      console.log('[popup init] Background OAuth state:', authState);
      if (authState.lastAuthStatus === 'failed' && authState.lastAuthError) {
        showStatus('error', `${authState.lastAuthError}`, '❌');
        await chrome.storage.local.remove(['lastAuthStatus', 'lastAuthError']);
      } else if (authState.lastAuthStatus === 'success') {
        showStatus('success', 'Logged in successfully with Google!', '🚀');
        await chrome.storage.local.remove(['lastAuthStatus', 'lastAuthError']);
      }
    } catch (err) {
      console.error('Error during startup initialization:', err);
    }
  }

  // Run initialization
  init();
});
